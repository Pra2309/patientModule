import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';  // Import CommonModule
import { RouterLink } from '@angular/router';


@Component({
  selector: 'app-view-payment-history',
  standalone: true,  // This marks the component as standalone
  imports: [CommonModule, RouterLink],  // Import CommonModule for ngClass and other Angular directives
  templateUrl: './view-payment-history.component.html',
  styleUrls: ['./view-payment-history.component.scss']
})
export class ViewPaymentHistoryComponent {
  isSidebarOpen = false;

  toggleSidebar() {
    this.isSidebarOpen = !this.isSidebarOpen;
  }
}
