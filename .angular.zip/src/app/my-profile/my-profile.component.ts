// src/app/my-profile/my-profile.component.ts
import { CommonModule } from '@angular/common'; 
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms'; // For ngModel
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker'; // Import datepicker module
import { MatNativeDateModule } from '@angular/material/core'; // Import Native Date module
@Component({
  selector: 'app-my-profile',
  standalone: true,
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.scss'],
  imports: [
    CommonModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    MatDatepickerModule,  // Add datepicker module
    MatNativeDateModule   // Add Native Date module
  ]
})
export class MyProfileComponent {
  name = '';
  medicalRecordNumber = '';
  email = '';
  dob = '';
  gender = '';
  bloodGroup = '';
  address = '';
  phone = '';
  genders = ['Male', 'Female', 'Other'];
  bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
  selectedGender: string = '';
  selectedBloodGroup: string = '';
  imageUrl: string | ArrayBuffer | null = null;  // Variable for image preview
  // Form submit function
  onSubmit() {
    console.log('Form submitted:', {
      name: this.name,
      medicalRecordNumber: this.medicalRecordNumber,
      email: this.email,
      dob: this.dob,
      gender: this.gender,
      bloodGroup: this.bloodGroup,
      address: this.address,
      phone: this.phone
    });
  }
  // Handle file change for image upload
  onFileChange(event: any) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        this.imageUrl = reader.result; // Store image URL to display
      };
      reader.readAsDataURL(file);
    }
  }
}