import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-UT3CIJT6.js";
import "./chunk-T4EQQY7M.js";
import "./chunk-NSSX5NIB.js";
import "./chunk-NAL5OIGY.js";
import "./chunk-5QJXQMPL.js";
import "./chunk-SLYRNZY6.js";
import "./chunk-EXXH5G64.js";
import "./chunk-QURFE6Q4.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
