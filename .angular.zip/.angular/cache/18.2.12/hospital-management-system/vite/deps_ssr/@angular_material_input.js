import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-WVUKVWST.js";
import "./chunk-EHKH65WR.js";
import "./chunk-L73CAP3D.js";
import "./chunk-TJXNGULE.js";
import "./chunk-QDF2QMUQ.js";
import "./chunk-F4JSRFGO.js";
import "./chunk-2WG5QLMT.js";
import "./chunk-FB6BDKAH.js";
import "./chunk-NQ4HTGF6.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
