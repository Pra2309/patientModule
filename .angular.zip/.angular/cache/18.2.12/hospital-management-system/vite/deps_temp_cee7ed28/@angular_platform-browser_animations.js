import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-M2XGKUDH.js";
import "./chunk-YG5UG652.js";
import "./chunk-MGNZONQE.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-2ZUF24MN.js";
import "./chunk-EPAV4CNQ.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
//# sourceMappingURL=@angular_platform-browser_animations.js.map
